# Salo UI Kit — Feed Items, Comments, Photo Upload

Three components for the "Feed Items, Interactions, and Media" phase, built
as a set since they share design tokens and two of them nest together.

## What's inside

```
src/
├── types/household.ts        Shared types (HouseholdPost, HouseholdComment, HouseholdMember)
├── lib/
│   ├── cn.ts                 Minimal classnames helper (no shadcn dependency required)
│   └── format.ts             formatTimeAgo, formatPHP, formatBytes, role color tokens, category icons
└── components/
    ├── feed/
    │   ├── HouseholdActivityFeed.tsx   Feed + post card: content, photo, category/amount, reactions
    │   └── CommentsThread.tsx          List + input. Used inline by the feed card, or standalone.
    └── post/
        └── PhotoUploadField.tsx        Drop-in for CreatePostModal: drag/drop, preview, remove
```

## Setup

```bash
npm install lucide-react
```

Everything imports via the `@/*` alias, matching the `create-next-app
--import-alias "@/*" --src-dir` scaffold from Phase 1. Drop the `src/`
contents into your existing `src/` folder (merge, don't overwrite anything
you've already built) and the imports resolve as-is.

## How the pieces fit together

- `HouseholdActivityFeed` renders one `PostCard` per post. Tapping a photo
  opens a lightbox. Tapping the comment button expands an inline
  `CommentsThread` for that post — the same component you'd use on its own
  if you build a dedicated post-detail view later.
- `PhotoUploadField` is standalone and unopinionated about where it lives —
  it just hands you a `File` via `onChange`. Drop it into `CreatePostModal`
  wherever the photo picker goes.

## What's real vs. what's a stand-in

I don't have your actual `CreatePostModal.tsx` or `convex/schema.ts` in
this session, so nothing here talks to Convex yet — that's the deliberate
boundary of a "UI only" pass. Specifically mocked, flagged in-code where it
happens:

- **Reactions** — toggles local state only. Wire `onReact` to your
  `api.reactions.toggle` mutation.
- **Comments** — `handleAddComment` in `HouseholdActivityFeed` appends
  optimistically to local state. Wire `onAddComment` to your
  `api.comments.create` mutation, and `onComment` (fires when a thread is
  opened) is a good spot to lazy-load real comments from Convex the first
  time, if you're not fetching them all upfront.
- **Photo compression** — `PhotoUploadField` fakes a 900ms "Compressing…"
  step with `window.setTimeout`. The block is commented
  `--- placeholder for the real client-side compression step ---` — replace
  it with your actual compress-then-upload call.
- **Mock feed photo** — `MOCK_POSTS` in `HouseholdActivityFeed.tsx` points
  at a placeholder image service (picsum.photos) purely so the photo/
  lightbox states render in local preview. Swap for real Convex storage
  URLs.

## Design decisions carried over from the earlier pass

- Role colors are grounded in the product, not decorative: sky/blue for the
  OFW (across the ocean), amber for the family at home (hearth, warmth).
- No nested cards — the category/amount strip and comment bubbles are tinted
  fills, never a second bordered+shadowed card inside the post.
- Expense amounts use `tabular-nums` on the regular sans face, not
  monospace.
- "Need" posts never get a red/urgent treatment.
- All interactive controls are `h-11` (44px) minimum for touch targets;
  focus-visible rings throughout; entrance animation respects
  `prefers-reduced-motion`.

## Known simplifications, worth revisiting later

- `CommentsThread`'s textarea doesn't auto-grow past one row's visual
  height on overflow — it scrolls internally instead. Fine for short
  comments, worth a proper auto-resize if long comments turn out common.
- `PhotoUploadField` supports one photo, matching the current schema's
  single `photoUrl` per post. If that ever becomes multi-photo, the preview
  state (`file`/`previewUrl`) needs to become an array.
